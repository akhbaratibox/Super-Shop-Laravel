<?php $__currentLoopData = json_decode($subcategory->additional_fields); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $af): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group">
    	<label class="col-lg-2 control-label"><?php echo e($af); ?></label>
    	<div class="col-lg-7">
    		<input type="text" placeholder="Enter field value" name="af_values[]"
            <?php if(isset(json_decode($product->additional_fields)->$key)): ?>
                value="<?php echo e(json_decode($product->additional_fields)->$key); ?>"
            <?php endif; ?> class="form-control">
    	</div>
        <div class="col-lg-2">
            <label class="switch" style="margin-top:5px;">
                <input value="<?php echo e($key); ?>" type="checkbox" name="active[]" <?php if(is_array(json_decode($product->quick_overview)) && in_array($key, json_decode($product->quick_overview))): ?>
                    checked
                <?php endif; ?>>
                <span class="slider round"></span>
            </label>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
