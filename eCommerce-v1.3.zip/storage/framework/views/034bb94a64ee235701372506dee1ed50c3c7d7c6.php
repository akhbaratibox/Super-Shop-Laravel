<?php $__env->startSection('content'); ?>

<div class="col-sm-6">
    <div class="panel">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo e(__('web.seller_information')); ?></h3>
        </div>

        <!--Horizontal Form-->
        <!--===================================================-->
        <form class="form-horizontal" action="<?php echo e(route('sellers.update', $seller->id)); ?>" method="POST" enctype="multipart/form-data">
            <input name="_method" type="hidden" value="PATCH">
        	<?php echo csrf_field(); ?>
            <div class="panel-body">
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="name"><?php echo e(__('web.name')); ?></label>
                    <div class="col-sm-9">
                        <input type="text" placeholder="<?php echo e(__('web.name')); ?>" id="name" name="name" class="form-control" value="<?php echo e($seller->user->name); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="email"><?php echo e(__('web.email_address')); ?></label>
                    <div class="col-sm-9">
                        <input type="text" placeholder="<?php echo e(__('web.email_address')); ?>" id="email" name="email" class="form-control" value="<?php echo e($seller->user->email); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="password"><?php echo e(__('web.password')); ?></label>
                    <div class="col-sm-9">
                        <input type="password" placeholder="<?php echo e(__('web.password')); ?>" id="password" name="password" class="form-control">
                    </div>
                </div>
            </div>
            <div class="panel-footer text-right">
                <button class="btn btn-purple" type="submit"><?php echo e(__('web.save')); ?></button>
            </div>
        </form>
        <!--===================================================-->
        <!--End Horizontal Form-->

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>